const jsConfuser = require("js-confuser");
const fs = require("fs");

/**
 * Função para criptografar (ofuscar) o conteúdo de um arquivo fornecido.
 * @param {string} inputFilePath - Caminho do arquivo a ser criptografado.
 * @param {string} outputFilePath - Caminho onde o arquivo ofuscado será salvo.
 */
async function obfuscateFile(inputFilePath, outputFilePath) {
  try {
    const fileContent = fs.readFileSync(inputFilePath, "utf-8");

    const obfuscationOptions = {
      target: "node",
      preset: "high",
      compact: true,
      minify: true,
      flatten: true,
      identifierGenerator: function () {
        function generateRandomString(length) {
          let result = '';
          const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
          const charactersLength = characters.length;
          for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
          }
          return result;
        }
        return "素晴座素晴難MHZIN素晴座素晴難素晴座素晴難MHZIN素晴座素晴難".replace(/[^a-zA-Z座MHZ素mhz1n素晴]/g, '') + generateRandomString(2);
      },
      renameVariables: true,
      renameGlobals: true,
      stringEncoding: true,
      stringSplitting: 0,
      stringConcealing: true,
      stringCompression: true,
      duplicateLiteralsRemoval: 1,
      shuffle: {
        hash: 0,
        true: 0
      },
      stack: true,
      controlFlowFlattening: 1,
      opaquePredicates: 0.9,
      deadCode: 0,
      dispatcher: true,
      rgf: false,
      calculator: true,
      hexadecimalNumbers: true,
      movedDeclarations: true,
      objectExtraction: true,
      globalConcealing: true
    };

    const obfuscatedCode = await jsConfuser.obfuscate(fileContent, obfuscationOptions);
    fs.writeFileSync(outputFilePath, obfuscatedCode);
  } catch (error) {
    console.error("Erro ao criptografar o arquivo:", error.message);
  }
}

// Exportando a função para ser usada em outro lugar
module.exports = {
  obfuscateFile
};
