const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const axios = require("axios");
const os = require('os')
const path = require('path');
const multer = require('multer');
const { obfuscateFile } = require('./scraper/criptografar/encrypt');
const app = express();

const PORT = 8080;
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, os.tmpdir()); // Usando a pasta temporária do sistema
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname); // Mantém o nome original do arquivo
  }
});
const upload = multer({ dest: 'scraper/uploads/criptografados/' }); // Diretório temporário para upload inicial

const originalFilesDir = path.join(__dirname, 'scraper/uploads/arquivos-originais');
const obfuscatedFilesDir = path.join(__dirname, 'scraper/uploads/criptografados');

// Criar diretórios se não existirem
[originalFilesDir, obfuscatedFilesDir].forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});


const apiRoutes = require('./apis');

app.set('trust proxy', true);

app.set('json spaces', 2);

app.use(express.static('public'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
  secret: 'mhz1n', 
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/paginas/encrypt.html');
});


app.post('/upload', upload.single('file'), async (req, res) => {
  if (!req.file || path.extname(req.file.originalname) !== '.js') {
    return res.status(400).send('Por favor, envie um arquivo JavaScript.');
  }

  const originalFilePath = path.join(originalFilesDir, req.file.originalname);
  const obfuscatedFilePath = path.join(obfuscatedFilesDir, `obfuscated_${Date.now()}_${req.file.originalname}`);

  try {
    // Mover o arquivo original para a pasta correta
    fs.renameSync(req.file.path, originalFilePath);

    // Criar o arquivo ofuscado temporário
    await obfuscateFile(originalFilePath, obfuscatedFilePath);

    res.download(obfuscatedFilePath, req.file.originalname, (err) => {
      if (err) {
        console.error('Erro ao enviar o arquivo:', err);
      }

      // Apagar o arquivo criptografado após o download
      fs.unlink(obfuscatedFilePath, (err) => {
        if (err) console.error('Erro ao apagar arquivo ofuscado:', err);
      });
    });
  } catch (error) {
    console.error('Erro ao processar o arquivo:', error);
    res.status(500).send('Erro ao processar o arquivo.');
  }
});

app.get('*', (req, res) => {
  res.sendFile(__dirname + '/public/paginas/encrypt.html');
});

app.listen(PORT, () => {
  console.log(`Site rodando em: localhost:${PORT}`);
});

